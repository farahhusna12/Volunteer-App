package com.example.volunteerapp.admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.volunteerapp.adapter.ViewParticipantsAdapter;
import com.example.volunteerapp.LoginActivity;
import com.example.volunteerapp.R;
import com.example.volunteerapp.model.Participation;
import com.example.volunteerapp.model.User;
import com.example.volunteerapp.remote.ApiUtils;
import com.example.volunteerapp.remote.ParticipationService;
import com.example.volunteerapp.sharedpref.SharedPrefManager;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewParticipantsActivity extends AppCompatActivity {
    private ViewParticipantsAdapter adapter;
    private ParticipationService participantService;
    private RecyclerView rvParticipants;
    private TextView noParticipantTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_participants);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.participantList), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rvParticipants = findViewById(R.id.participantList);
        noParticipantTextView = findViewById(R.id.noparticipant);

        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();
        String token = user.getToken();
        int user_id = user.getId();

        ImageView imageBackHome = findViewById(R.id.backHome);
        imageBackHome.setOnClickListener(v -> backHome());

        participantService = ApiUtils.getParticipationService();
        int event_id = getIntent().getIntExtra("event_id", -1);

        participantService.getParticipations(token, event_id).enqueue(new Callback<List<Participation>>() {
            @Override
            public void onResponse(Call<List<Participation>> call, Response<List<Participation>> response) {
                Log.d("MyApp:", "Response: " + response.raw().toString());

                if (response.code() == 200) {
                    List<Participation> participants = response.body();

                    if (participants != null && !participants.isEmpty()) {
                        noParticipantTextView.setVisibility(View.GONE); // Hide if participants exist
                        rvParticipants.setVisibility(View.VISIBLE);

                        adapter = new ViewParticipantsAdapter(getApplicationContext(), participants);
                        rvParticipants.setAdapter(adapter);
                        rvParticipants.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

                        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(
                                rvParticipants.getContext(), DividerItemDecoration.VERTICAL);
                        rvParticipants.addItemDecoration(dividerItemDecoration);
                    } else {
                        noParticipantTextView.setVisibility(View.VISIBLE); // Show if no participants
                        rvParticipants.setVisibility(View.GONE);
                    }
                } else if (response.code() == 401) {
                    Toast.makeText(getApplicationContext(), "Invalid session. Please login again", Toast.LENGTH_LONG).show();
                    clearSessionAndRedirect();
                }
            }

            @Override
            public void onFailure(Call<List<Participation>> call, Throwable t) {
                Toast.makeText(ViewParticipantsActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void clearSessionAndRedirect() {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();
        finish();
        startActivity(new Intent(this, LoginActivity.class));
    }

    private void backHome() {
        Intent intent = new Intent(getApplicationContext(), AdminDashboardActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}

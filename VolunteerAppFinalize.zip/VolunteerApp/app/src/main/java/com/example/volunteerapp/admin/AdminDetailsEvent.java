package com.example.volunteerapp.admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.example.volunteerapp.LoginActivity;
import com.example.volunteerapp.R;
import com.example.volunteerapp.model.Event;
import com.example.volunteerapp.model.User;
import com.example.volunteerapp.remote.ApiUtils;
import com.example.volunteerapp.remote.EventService;
import com.example.volunteerapp.sharedpref.SharedPrefManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminDetailsEvent extends AppCompatActivity {

    private EventService eventService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_event_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();
        String token = user.getToken();

        // Retrieve the event object passed from the previous activity
        Event event = (Event) getIntent().getSerializableExtra("event");

        if (event == null) {
            Toast.makeText(getApplicationContext(), "Invalid Event", Toast.LENGTH_SHORT).show();
            finish();  // Close activity if the event data is null
            return;
        }

        // Initialize buttons
        Button btnUpdate = findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(v -> btnUpdateClicked());

        Button btnDelete = findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(v -> deleteEvent(event.getEvent_id(), token));

        // Initialize eventService for API calls
        eventService = ApiUtils.getEventService();

        // Fetch event details from the API
        eventService.getEvent(token, event.getEvent_id()).enqueue(new Callback<Event>() {
            @Override
            public void onResponse(Call<Event> call, Response<Event> response) {
                if (response.isSuccessful()) {
                    Event eventDetails = response.body();

                    if (eventDetails != null) {
                        // Set values to the views
                        TextView tvEventName = findViewById(R.id.tvEventName);
                        TextView tvDesc = findViewById(R.id.tvEventDescription);
                        TextView tvLocation = findViewById(R.id.tvLocation);
                        TextView tvDate = findViewById(R.id.tvDate);
                        TextView tvCategory = findViewById(R.id.tvCategory);

                        tvEventName.setText(eventDetails.getEvent_name());
                        tvLocation.setText(eventDetails.getLocation());
                        tvDate.setText(eventDetails.getDate());
                        tvDesc.setText(eventDetails.getDescription());
                        tvCategory.setText(eventDetails.getCategory());

                        ImageView activityImage = findViewById(R.id.imgEvent);
                        Glide.with(getApplicationContext())
                                .load("https://codelah.my/2022484414/api/" + eventDetails.getImage())
                                .placeholder(R.drawable.default_cover)  // Placeholder if image URL is empty
                                .error(R.drawable.default_cover)  // Error image if loading fails
                                .into(activityImage);
                    }
                } else if (response.code() == 401) {
                    // Unauthorized error, prompt user to log in again
                    Toast.makeText(getApplicationContext(), "Invalid session. Please login again", Toast.LENGTH_LONG).show();
                    clearSessionAndRedirect();
                } else {
                    Toast.makeText(getApplicationContext(), "Error: " + response.message(), Toast.LENGTH_LONG).show();
                    Log.e("MyApp:", response.toString());
                }
            }

            @Override
            public void onFailure(Call<Event> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Error connecting to the server", Toast.LENGTH_LONG).show();
                Log.e("MyApp:", t.toString());
            }
        });
    }

    private void btnUpdateClicked() {
        // Get the event object passed from the previous activity
        Event event = (Event) getIntent().getSerializableExtra("event");

        // Retrieve the eventId from the Event object
        int eventId = event.getEvent_id();  // Assuming `getId()` is a method in your `Event` model

        // Create an Intent to open the AdminUpdateEvent activity
        Intent intent = new Intent(getApplicationContext(), AdminUpdateEvent.class);

        // Pass the eventId to the AdminUpdateEvent activity
        intent.putExtra("event_id", eventId);

        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }



    private void deleteEvent(int eventId, String token) {
        if (eventId == -1) {
            Toast.makeText(getApplicationContext(), "Invalid Event ID", Toast.LENGTH_SHORT).show();
            return;
        }

        eventService.deleteEvent(token, eventId).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(getApplicationContext(), "Event deleted successfully", Toast.LENGTH_SHORT).show();

                    // Redirect back to AdminUpcomingActivity
                    Intent intent = new Intent(getApplicationContext(), AdminUpcomingActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), "Failed to delete event", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Error deleting event", Toast.LENGTH_SHORT).show();
                Log.e("DeleteEvent", "Error: " + t.getMessage());
            }
        });
    }

    public void clearSessionAndRedirect() {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();
        finish();
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    public void BackUpcomingEventClicked(View view) {
        Intent intent = new Intent(getApplicationContext(), AdminUpcomingActivity.class);
        startActivity(intent);
    }
}

package com.example.volunteerapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.volunteerapp.model.User;
import com.example.volunteerapp.sharedpref.SharedPrefManager;
import com.example.volunteerapp.user.DashboardActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();

        TextView tvUsername = findViewById(R.id.tvUsername);
        TextView tvEmail = findViewById(R.id.tvEmail);

        ImageView activityImage = findViewById(R.id.activityImage);
        Log.d("ImageURL", "URL: https://codelah.my/2022484414/api/" + user.getImage());
        // Use Glide to load the image into the ImageView
        Glide.with(getApplicationContext())
                .load("https://codelah.my/2022484414/api/" + user.getImage())
                .placeholder(R.drawable.default_cover) // Placeholder image if the URL is empty
                .error(R.drawable.default_cover) // Error image if there is a problem loading the image
                .into(activityImage);

        ImageView imageBackHome = findViewById(R.id.backHome);
        imageBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backHome();
            }
        });

        TextView logOut = findViewById(R.id.logoutText);
        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {logoutClicked();
            }
        });

        TextView profileDetail = findViewById(R.id.profileDetail);
        profileDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {profileDetailClicked();
            }
        });
        tvUsername.setText(user.getUsername());
        tvEmail.setText(user.getEmail());

    }

    private void profileDetailClicked() {
        Intent intent = new Intent(getApplicationContext(), ProfileDetailActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
    }

    private void logoutClicked() {
        // clear the shared preferences
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();

        // display message
        Toast.makeText(getApplicationContext(),
                "You have successfully logged out.",
                Toast.LENGTH_LONG).show();

        // terminate this MainActivity
        finish();

        // forward to Login Page
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void backHome() {
        Intent intent = new Intent(getApplicationContext(), DashboardActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
    }
}
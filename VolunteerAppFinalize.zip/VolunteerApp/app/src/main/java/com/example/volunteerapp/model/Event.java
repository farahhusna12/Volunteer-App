package com.example.volunteerapp.model;

import java.io.Serializable;

public class Event implements Serializable {

    private int event_id;
    private String event_name;
    private String description;
    private String image;
    private String location;
    private String date;
    private String category;

    public Event(String event_name, String description, String location, String date , String category) {
        this.event_name = event_name;
        this.description = description;
        this.location = location;
        this.date = date;
        this.category=category;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getEvent_id() {
        return event_id;
    }

    public void setEvent_id(int event_id) {
        this.event_id = event_id;
    }

    public String getEvent_name() {
        return event_name;
    }

    public void setEvent_name(String event_name) {
        this.event_name = event_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}

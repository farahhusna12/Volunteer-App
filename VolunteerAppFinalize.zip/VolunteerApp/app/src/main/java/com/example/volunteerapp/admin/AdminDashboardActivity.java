package com.example.volunteerapp.admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.volunteerapp.ProfileActivity;
import com.example.volunteerapp.adapter.AdminCurrentActivityAdapter;
import com.example.volunteerapp.LoginActivity;
import com.example.volunteerapp.R;
import com.example.volunteerapp.model.Event;
import com.example.volunteerapp.model.User;
import com.example.volunteerapp.remote.EventService;
import com.example.volunteerapp.remote.ApiUtils;
import com.example.volunteerapp.sharedpref.SharedPrefManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminDashboardActivity extends AppCompatActivity {

    private EventService eventService;
    private RecyclerView recyclerView3;
    private List<Event> activityList;
    private AdminCurrentActivityAdapter adapter;
    private TextView curDate;
    String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.dashboard_admin);

        // Apply insets for edge-to-edge design
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.dashboardadmin), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();

        TextView tvUsername = findViewById(R.id.username);
        tvUsername.setText("Hi "+ user.getUsername() +" !");

        curDate = findViewById(R.id.current_date);
        date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        curDate.setText(date);

        // Initialize RecyclerView
        recyclerView3 = findViewById(R.id.recyclerView3);
        recyclerView3.setLayoutManager(new LinearLayoutManager(this));
        recyclerView3.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        // Initialize empty adapter
        adapter = new AdminCurrentActivityAdapter(this, List.of());
        recyclerView3.setAdapter(adapter);

        // Register context menu for RecyclerView
        registerForContextMenu(recyclerView3);

        // Update RecyclerView with data
        updateRecyclerView();

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_home);

        bottomNavigationView.setOnItemSelectedListener(item -> {

            if (item.getItemId() == R.id.nav_home) {
                return true;
            } else if (item.getItemId() == R.id.nav_upcoming) {
                startActivity(new Intent(getApplicationContext(), AdminUpcomingActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (item.getItemId() == R.id.nav_profile) {
                startActivity(new Intent(getApplicationContext(), AdminProfileActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (item.getItemId() == R.id.nav_logout) {
                // Show confirmation dialog
                new AlertDialog.Builder(this)
                        .setTitle("Logout Confirmation")
                        .setMessage("Are you sure you want to logout?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            // User confirmed logout
                            Toast.makeText(this, "You have been logged out.", Toast.LENGTH_SHORT).show();

                            // Navigate to LoginActivity
                            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                            finish();
                        })
                        .setNegativeButton("No", (dialog, which) -> {
                            // User canceled logout
                            dialog.dismiss();
                        })
                        .show();
                return true;
            }
            return false;
        });

    }

    private void updateRecyclerView() {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();
        String token = user.getToken();
        int organizerId = user.getId();

        eventService = ApiUtils.getEventService();

        // Get today's date
        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // First, make the API call to get all events (which includes both past and future events)
        eventService.getEventsOrganizer(token,organizerId).enqueue(new Callback<List<Event>>() {
            @Override
            public void onResponse(Call<List<Event>> call, Response<List<Event>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<Event> allEvents = response.body();

                    // Count the number of upcoming events
                    int upcomingCount = countUpcomingEvents(allEvents, currentDate);
                    TextView upcomingCountTextView = findViewById(R.id.total_upcoming);
                    upcomingCountTextView.setText(String.valueOf(upcomingCount));
                } else {
                    Log.e("MyApp:", "Failed to get all events: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<List<Event>> call, Throwable t) {
                // Handle failure to connect
                Toast.makeText(getApplicationContext(), "Error connecting to the server", Toast.LENGTH_LONG).show();
                Log.e("MyApp:", t.toString());
            }
        });

        // Get events filtered by date and organizerId
        eventService.getEventsByDateAndOrganizer(token, currentDate, organizerId).enqueue(new Callback<List<Event>>() {
            @Override
            public void onResponse(Call<List<Event>> call, Response<List<Event>> response) {
                Log.d("MyApp:", "Response: " + response.raw());

                if (response.isSuccessful() && response.body() != null) {
                    List<Event> allEvents = response.body();
                    adapter.updateData(allEvents); // Update adapter with all events

                    // Count the number of current events
                    int currentCount = allEvents.size();
                    TextView eventCountTextView = findViewById(R.id.total_current);
                    eventCountTextView.setText(String.valueOf(currentCount));
                } else if (response.code() == 401) {
                    // Handle invalid token case
                    Toast.makeText(AdminDashboardActivity.this, "Invalid session. Please login again", Toast.LENGTH_LONG).show();
                    clearSessionAndRedirect();
                } else {
                    // Handle other errors
                    Toast.makeText(AdminDashboardActivity.this, "Error: " + response.message(), Toast.LENGTH_LONG).show();
                    Log.e("MyApp:", response.toString());
                }
            }

            @Override
            public void onFailure(Call<List<Event>> call, Throwable t) {
                // Handle failure to connect
                Toast.makeText(getApplicationContext(), "Error connecting to the server", Toast.LENGTH_LONG).show();
                Log.e("MyApp:", t.toString());
            }
        });
    }

    // Count upcoming events based on the current date
    private int countUpcomingEvents(List<Event> events, String currentDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        int upcomingCount = 0;

        for (Event event : events) {
            try {
                String eventDateString = event.getDate();
                Log.d("EventDate", "Event Date: " + eventDateString);

                if (eventDateString == null || eventDateString.isEmpty()) {
                    Log.e("EventDate", "Event date is null or empty.");
                    continue;
                }

                Date eventDate = dateFormat.parse(eventDateString);
                Date todayDate = dateFormat.parse(currentDate);

                if (eventDate != null && eventDate.after(todayDate)) {
                    upcomingCount++;
                }
            } catch (Exception e) {
                Log.e("EventDate", "Error parsing date for event: " + e.getMessage());
            }
        }

        Log.d("UpcomingCount", "Upcoming Events Count: " + upcomingCount);
        return upcomingCount;
    }

    public void clearSessionAndRedirect() {
        // Clear shared preferences and redirect to login
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();

        finish();
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}



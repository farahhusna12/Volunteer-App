package com.example.volunteerapp.admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.example.volunteerapp.LoginActivity;
import com.example.volunteerapp.ProfileDetailActivity;
import com.example.volunteerapp.R;
import com.example.volunteerapp.model.User;
import com.example.volunteerapp.sharedpref.SharedPrefManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AdminProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_profile);

        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        TextView tvUsername = findViewById(R.id.tvUsername);
        TextView tvEmail = findViewById(R.id.tvEmail);

        ImageView activityImage = findViewById(R.id.profileImage);
        Log.d("ImageURL", "URL: https://codelah.my/2022484414/api/" + user.getImage());
        // Use Glide to load the image into the ImageView
        Glide.with(getApplicationContext())
                .load("https://codelah.my/2022484414/api/" + user.getImage())
                .placeholder(R.drawable.profile) // Placeholder image if the URL is empty
                .error(R.drawable.profile) // Error image if there is a problem loading the image
                .into(activityImage);

        Button updateprofile = findViewById(R.id.BtnUpdate);
        updateprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BtnProfileClicked();
            }
        });
        tvUsername.setText(user.getUsername());
        tvEmail.setText(user.getEmail());
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_home) {
                startActivity(new Intent(getApplicationContext(), AdminDashboardActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (item.getItemId() == R.id.nav_upcoming) {
                startActivity(new Intent(getApplicationContext(), AdminUpcomingActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (item.getItemId() == R.id.nav_profile) {
                return true;
            } else if (item.getItemId() == R.id.nav_logout) {
                // Show logout confirmation dialog
                showLogoutConfirmation();
                return true;
            }
            return false;
        });
    }

        private void BtnProfileClicked() {
            Intent intent = new Intent(getApplicationContext(), AdminProfileUpdateActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
        }

    public void clearSessionAndRedirect() {
        // Clear shared preferences and redirect to login
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        finish(); // Ensure activity is removed from the back stack
    }

    private void showLogoutConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Logout Confirmation")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    // Display success message
                    Toast.makeText(this, "You have been logged out.", Toast.LENGTH_SHORT).show();

                    // Clear session and redirect to LoginActivity
                    clearSessionAndRedirect();
                })
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                .show();
    }
}
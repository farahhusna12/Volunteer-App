package com.example.volunteerapp.admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.volunteerapp.adapter.AdminUpcomingActivityAdapter;
import com.example.volunteerapp.LoginActivity;
import com.example.volunteerapp.R;
import com.example.volunteerapp.model.Event;
import com.example.volunteerapp.model.User;
import com.example.volunteerapp.remote.ApiUtils;
import com.example.volunteerapp.sharedpref.SharedPrefManager;
import com.example.volunteerapp.remote.EventService;
import com.example.volunteerapp.user.EventListDetailActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminUpcomingActivity extends AppCompatActivity {

    private EventService eventService;
    private RecyclerView recyclerView4;
    private AdminUpcomingActivityAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.admin_upcoming_event);

        // Apply insets for edge-to-edge design
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.upcoming_event), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize RecyclerView
        recyclerView4 = findViewById(R.id.recyclerView4);
        recyclerView4.setLayoutManager(new LinearLayoutManager(this));
        recyclerView4.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        // Initialize empty adapter
        adapter = new AdminUpcomingActivityAdapter(getApplicationContext(), new ArrayList<>(), event -> {
            Intent intent = new Intent(getApplicationContext(), AdminDetailsEvent.class);
            intent.putExtra("event", (Serializable) event); // Pass event safely
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        recyclerView4.setAdapter(adapter);

        // Register context menu for RecyclerView
        registerForContextMenu(recyclerView4);

        // Update RecyclerView with data
        updateRecyclerView();

        // Set up BottomNavigationView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_upcoming);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_home) {
                startActivity(new Intent(getApplicationContext(), AdminDashboardActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (item.getItemId() == R.id.nav_upcoming) {
                return true;
            } else if (item.getItemId() == R.id.nav_profile) {
                startActivity(new Intent(getApplicationContext(), AdminProfileActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (item.getItemId() == R.id.nav_logout) {
                // Show logout confirmation dialog
                showLogoutConfirmation();
                return true;
            }
            return false;
        });
    }

    private void updateRecyclerView() {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();
        String token = user.getToken();
        int organizerId = user.getId();

        try {
            // Get the current date
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date currentDate = dateFormat.parse(dateFormat.format(new Date()));

            // Make API call to get all events for the organizer
            eventService = ApiUtils.getEventService();
            eventService.getEventsOrganizer(token, organizerId).enqueue(new Callback<List<Event>>() {
                @Override
                public void onResponse(Call<List<Event>> call, Response<List<Event>> response) {
                    Log.d("MyApp:", "Response: " + response.raw());

                    if (response.isSuccessful() && response.body() != null) {
                        List<Event> eventList = response.body();
                        List<Event> filteredEvents = new ArrayList<>();

                        // Filter events where the event date is after the current date
                        for (Event event : eventList) {
                            try {
                                Date eventDate = dateFormat.parse(event.getDate());
                                if (eventDate != null && eventDate.after(currentDate)) {
                                    filteredEvents.add(event);
                                }
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                        }

                        // Update RecyclerView
                        if (adapter == null) {
                            adapter = new AdminUpcomingActivityAdapter(getApplicationContext(), filteredEvents, event -> {
                                Intent intent = new Intent(getApplicationContext(), EventListDetailActivity.class);
                                intent.putExtra("event", (Serializable) event);
                                startActivity(intent);
                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                            });
                            recyclerView4.setAdapter(adapter);
                        } else {
                            adapter.updateData(filteredEvents);
                        }
                    } else if (response.code() == 401) {
                        Toast.makeText(AdminUpcomingActivity.this, "Invalid session. Please login again", Toast.LENGTH_LONG).show();
                        clearSessionAndRedirect();
                    } else {
                        Toast.makeText(AdminUpcomingActivity.this, "Error: " + response.message(), Toast.LENGTH_LONG).show();
                        Log.e("MyApp:", response.toString());
                    }
                }

                @Override
                public void onFailure(Call<List<Event>> call, Throwable t) {
                    Toast.makeText(getApplicationContext(), "Error connecting to the server", Toast.LENGTH_LONG).show();
                    Log.e("MyApp:", t.toString());
                }
            });
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }


    public void AddEventClicked(View view) {
        // Forward user to AdminAddEvent activity
        Intent intent = new Intent(getApplicationContext(), AdminAddEvent.class);
        startActivity(intent);
    }

    public void clearSessionAndRedirect() {
        // Clear shared preferences and redirect to login
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        finish(); // Ensure activity is removed from the back stack
    }

    private void showLogoutConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Logout Confirmation")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    // Display success message
                    Toast.makeText(this, "You have been logged out.", Toast.LENGTH_SHORT).show();

                    // Clear session and redirect to LoginActivity
                    clearSessionAndRedirect();
                })
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                .show();
    }
}

package com.example.volunteerapp.user;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.volunteerapp.ProfileActivity;
import com.example.volunteerapp.R;
import com.example.volunteerapp.adapter.EventAdapter;
import com.example.volunteerapp.adapter.ParticipationAdapter;
import com.example.volunteerapp.model.Event;
import com.example.volunteerapp.model.Participation;
import com.example.volunteerapp.model.User;
import com.example.volunteerapp.remote.ApiUtils;
import com.example.volunteerapp.remote.EventService;
import com.example.volunteerapp.remote.ParticipationService;
import com.example.volunteerapp.sharedpref.SharedPrefManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardActivity extends AppCompatActivity {

    RecyclerView eventList;
    RecyclerView newEventList;
    EventService eventService;
    ParticipationService participationService;
    EventAdapter adapter;
    ParticipationAdapter participationAdapter;
    private ProgressBar progressBar4;
    private ProgressBar progressBar5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        TextView tvUsername = findViewById(R.id.tvUsername);
        ImageView evImageUser = findViewById(R.id.ivImgUser);
        progressBar4 = findViewById(R.id.progressBar4);
        progressBar5 = findViewById(R.id.progressBar5);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);

        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();

        tvUsername.setText(user.getUsername());

        Log.d("ImageURL", "URL: https://codelah.my/2022484414/api/" + user.getImage());
        // Use Glide to load the image into the ImageView
        Glide.with(getApplicationContext())
                .load("https://codelah.my/2022484414/api/" + user.getImage())
                .placeholder(R.drawable.default_cover) // Placeholder image if the URL is empty
                .error(R.drawable.default_cover) // Error image if there is a problem loading the image
                .into(evImageUser);

        //for new event
        eventList = findViewById(R.id.NewEventRV);

        eventService = ApiUtils.getEventService();

        eventService.getAllEvent(user.getToken()).enqueue(new Callback<List<Event>>(){

            @Override
            public void onResponse(@NonNull Call<List<Event>> call, @NonNull Response<List<Event>> response) {
                Log.d("MyApp:", "Response: " + response.raw().toString());

                if (progressBar4 != null) {
                    progressBar4.setVisibility(View.GONE);
                }

                List<Event> event = response.body();

                if (event != null) {
                    // Set the click listener to handle item clicks
                    adapter = new EventAdapter(getApplicationContext(), event, new EventAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(Event event) {
                            // When an item is clicked, navigate to the EventListDetailActivity
                            Intent intent = new Intent(getApplicationContext(), EventListDetailActivity.class);
                            intent.putExtra("event", event);  // Pass the event object
                            startActivity(intent);
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        }
                    });

                    eventList.setAdapter(adapter);
                    eventList.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));
                }

            }

            @Override
            public void onFailure(@NonNull Call<List<Event>> call, @NonNull Throwable t) {
                Toast.makeText(getApplicationContext(), "Error connecting to the server", Toast.LENGTH_LONG).show();
                Log.e("MyApp:", Objects.requireNonNull(t.getMessage()));
            }
        });

        //for user joined event

        TextView noEventMessage = findViewById(R.id.noEvent);

        newEventList = findViewById(R.id.currentRV);

        participationService = ApiUtils.getParticipationService();

        participationService.getParticipation(user.getToken(),user.getId()).enqueue(new Callback<List<Participation>>() {
            @Override
            public void onResponse(@NonNull Call<List<Participation>> call, @NonNull Response<List<Participation>> response) {

                Log.d("MyApp:", "Response: " + response.raw().toString());

                if (progressBar5 != null) {
                    progressBar5.setVisibility(View.GONE);
                }

                List<Participation> participation = response.body();

                // Check if the list is empty or null
                if (participation == null || participation.isEmpty()) {
                    newEventList.setVisibility(View.GONE); // Hide the RecyclerView
                    noEventMessage.setVisibility(View.VISIBLE); // Show the no event message
                } else {
                    participationAdapter = new ParticipationAdapter(getApplicationContext(), participation, new ParticipationAdapter.OnItemClickListener() {
                        public void onItemClick(Participation participation) {
                            // When an item is clicked, navigate to the EventUserDetailActivity
                            Intent intent = new Intent(getApplicationContext(), EventUserDetailActivity.class);
                            intent.putExtra("participation", participation);  // Pass the event object
                            startActivity(intent);
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        }
                    });

                    newEventList.setAdapter(participationAdapter);
                    newEventList.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));

                    newEventList.setVisibility(View.VISIBLE); // Show the RecyclerView if there are participations
                    noEventMessage.setVisibility(View.GONE); // Hide the no event message
                }

            }

            @Override
            public void onFailure(@NonNull Call<List<Participation>> call, @NonNull Throwable t) {
                Toast.makeText(getApplicationContext(), "Error connecting to the server", Toast.LENGTH_LONG).show();
                Log.e("MyApp:", Objects.requireNonNull(t.getMessage()));
            }
        });


        //for see all current event
        TextView eventUserAll = findViewById(R.id.seeCurrentActivity);
        eventUserAll.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), EventUserActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        //for see all new event
        TextView eventListAll = findViewById(R.id.seeNewActivity);
        eventListAll.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), EventListActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        bottomNavigationView.setSelectedItemId(R.id.nav_home);

        bottomNavigationView.setOnItemSelectedListener(item -> {

            if (item.getItemId() == R.id.nav_home) {
                return true;
            } else if (item.getItemId() == R.id.nav_profile) {
                startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            }
            else if (item.getItemId() == R.id.nav_reward) {
                startActivity(new Intent(getApplicationContext(), MissionActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            }

            else if (item.getItemId() == R.id.nav_achievement) {
                startActivity(new Intent(getApplicationContext(), AchievementActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            }
            return false;
        });
    }
}
package com.example.volunteerapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.volunteerapp.admin.AdminDashboardActivity;
import com.example.volunteerapp.model.FailLogin;
import com.example.volunteerapp.model.User;
import com.example.volunteerapp.remote.ApiUtils;
import com.example.volunteerapp.remote.UserService;
import com.example.volunteerapp.sharedpref.SharedPrefManager;
import com.example.volunteerapp.user.DashboardActivity;
import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText edtUsername;
    private EditText edtPassword;
    Call<User> call;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);

        ImageView imageViewLogin = findViewById(R.id.loginButton);
        imageViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginClick();
            }
        });
    }

    private void loginClick() {
        String username = edtUsername.getText().toString();
        String password = edtPassword.getText().toString();
        if (validateLogin(username, password)) {
            // if not empty, login using REST API
            doLogin(username, password);
        }
    }

    private void doLogin(String username, String password) {

        UserService userService = ApiUtils.getUserService();

        if(username.contains("@")){
            call = userService.loginEmail(username, password);
        }else{
            call = userService.login(username, password);
        }

        call.enqueue(new Callback<User>(){

            @Override
            public void onResponse(Call<User> call, Response<User> response) {

                if (response.isSuccessful()){
                    User user = (User) response.body();
                    if (user != null && user.getToken() != null){
                        displayToast("Login successful");
                        displayToast("Welcome "+user.getUsername());

                        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
                        spm.userLogin(user);

                        if ("admin".equalsIgnoreCase(user.getRole())) { // Check if user is an admin
                            startActivity(new Intent(getApplicationContext(), AdminDashboardActivity.class));
                        } else if ("user".equalsIgnoreCase(user.getRole())){
                            startActivity(new Intent(getApplicationContext(), DashboardActivity.class));
                        }
                        finish();
                        }else{
                        displayToast("Login error");
                    }
                }else{
                    String errorResp = null;
                    try {
                        errorResp = response.errorBody().string();
                        FailLogin e = new Gson().fromJson(errorResp, FailLogin.class);
                        displayToast(e.getError().getMessage());
                    } catch (Exception e) {
                        Log.e("MyApp:", e.toString()); // print error details to error log
                        displayToast("Error");
                    }
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                displayToast("Error connecting to server.");
                displayToast(t.getMessage());
                Log.e("MyApp:", t.toString()); // print error details to error log
            }
        });
    }

    private void displayToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private boolean validateLogin(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            displayToast("Username is required");
            return false;
        }
        if (password == null || password.trim().isEmpty()) {
            displayToast("Password is required");
            return false;
        }
        return true;
    }
}
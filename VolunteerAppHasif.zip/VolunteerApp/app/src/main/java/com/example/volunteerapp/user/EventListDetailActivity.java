package com.example.volunteerapp.user;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.example.volunteerapp.R;
import com.example.volunteerapp.model.Event;
import com.example.volunteerapp.model.Participation;
import com.example.volunteerapp.model.UpdatePoints;
import com.example.volunteerapp.model.User;
import com.example.volunteerapp.remote.ApiUtils;
import com.example.volunteerapp.remote.ParticipationService;
import com.example.volunteerapp.remote.UserService;
import com.example.volunteerapp.sharedpref.SharedPrefManager;

import java.sql.Date;
import java.util.Calendar;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EventListDetailActivity extends AppCompatActivity {

    private ImageView backHome;
    UpdatePoints updatePoints;
    Event event;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list_detail);

        TextView tvEventName = findViewById(R.id.tvEventName);
        TextView tvAddress = findViewById(R.id.tvAddress);
        TextView tvDate = findViewById(R.id.tvDate);
        //eventOrganizer = findViewById(R.id.tvOrganizer);
        Button joinEventBtn = findViewById(R.id.joinEventBtn);
        ImageView tvActivityImage = findViewById(R.id.tvActivityImage);
        TextView tvDescription = findViewById(R.id.tvDescription);

        // Get the event object from the Intent
        event = (Event) getIntent().getSerializableExtra("event");

        if (event != null) {
            tvEventName.setText(event.getEvent_name());
            tvAddress.setText(event.getLocation());
            tvDate.setText(event.getDate());
            tvDescription.setText(event.getDescription());
            //eventOrganizer.setText(event.getOrganizer());

            Glide.with(this)
                    .load("https://codelah.my/2022484414/api/" + event.getImage())
                    .placeholder(R.drawable.default_cover)
                    .error(R.drawable.default_cover)
                    .into(tvActivityImage);
        }

        ImageView backHome = findViewById(R.id.backHome);
        backHome.setOnClickListener(v -> {
            onBackPressed();
        });

        joinEventBtn.setOnClickListener(v -> {
            joinButtonClicked();
        });
    }

    private void joinButtonClicked() {
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        ParticipationService participationService = ApiUtils.getParticipationService();

        participationService.createParticipation(user.getToken(), user.getId(), event.getEvent_id()).enqueue(new Callback<Participation>() {
            @Override
            public void onResponse(@NonNull Call<Participation> call, @NonNull Response<Participation> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // Successfully joined the event
                    Toast.makeText(getApplicationContext(), "Successfully joined the event!", Toast.LENGTH_SHORT).show();

                    // Determine points based on the event category
                    int pointsToAdd = getPointsByCategory(event.getCategory());

                    // Update the user's points
                    updateUserPoints(user, pointsToAdd);

                    // Optionally, navigate to another activity
                    Intent intent = new Intent(getApplicationContext(), DashboardActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else {
                    // Handle unsuccessful responses
                    Toast.makeText(getApplicationContext(), "Failed to join the event. Please try again.", Toast.LENGTH_SHORT).show();
                    Log.e("Join Event", "Response code: " + response.code());
                }
            }

            @Override
            public void onFailure(@NonNull Call<Participation> call, @NonNull Throwable throwable) {
                Toast.makeText(getApplicationContext(), "Error connecting to the server", Toast.LENGTH_LONG).show();
                Log.e("MyApp:", Objects.requireNonNull(throwable.getMessage()));
            }
        });
    }

    // Helper method to get points by event category
    private int getPointsByCategory(String category) {
        switch (category) {
            case "Community":
                return 500;
            case "Healthcare":
                return 400;
            case "Environmental":
                return 300;
            case "Education":
                return 250;
            case "Entertainment":
                return 200;
            default:
                return 0;
        }
    }

    // Method to update the user's points
    private void updateUserPoints(User user, int pointsToAdd) {
        // Add the points to the user's total
        user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        int newTotalPoints = user.getPoints() + pointsToAdd;

        UpdatePoints updatePoints = new UpdatePoints(user.getId(),newTotalPoints);

        UserService userService = ApiUtils.getUserService();

        // Call the API
        userService.updateUserPoints(user.getToken(), user.getId(), updatePoints).enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.isSuccessful()) {
                    User updatedUser = response.body();
                    if (updatedUser != null) {
                        SharedPrefManager.getInstance(getApplicationContext()).saveUser(updatedUser);
                    }
                    Log.d("Update Points", "User points updated successfully!");
                    Log.d("Update Points", "User points "+ newTotalPoints);
                    Log.d("API Response", response.body().toString());


                    // Optionally update UI or notify user
                } else {
                    Log.e("Update Points", "Takleh add point lagi check error: " + response.code() + " - " + response.message());
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Log.e("Update Points", "Failed to update points: " + t.getMessage());
            }
        });
    }


}
